﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Supermarket_Management_System_In_csharp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmlogin());
        }
    }
}
